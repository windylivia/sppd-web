<?php
include("../koneksi.php");

$id_tingkatan = $_GET['id'];

$query = "DELETE FROM tingkatan WHERE id_tingkatan = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_tingkatan);
$stmt->execute();

header("Location: index.php");
?>