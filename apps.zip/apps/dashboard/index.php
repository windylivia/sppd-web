<?php
include("../koneksi.php");
$menu = $conn->query("SELECT * FROM menu");

// Hitung jumlah total golongan
$query_golongan = $conn->query("SELECT COUNT(*) as total_golongan FROM golongan");
$data_golongan = $query_golongan->fetch_assoc();
$total_golongan = $data_golongan['total_golongan'];

// Hitung jumlah total jabatan
$query_jabatan = $conn->query("SELECT COUNT(*) as total_jabatan FROM jabatan");
$data_jabatan = $query_jabatan->fetch_assoc();
$total_jabatan = $data_jabatan['total_jabatan'];

// Hitung jumlah total pangkat
$query_pangkat = $conn->query("SELECT COUNT(*) as total_pangkat FROM pangkat");
$data_pangkat = $query_pangkat->fetch_assoc();
$total_pangkat = $data_pangkat['total_pangkat'];

// Hitung jumlah total tingkatan
$query_tingkatan = $conn->query("SELECT COUNT(*) as total_tingkatan FROM tingkatan");
$data_tingkatan = $query_tingkatan->fetch_assoc();
$total_tingkatan = $data_tingkatan['total_tingkatan'];

// Hitung jumlah total pegawai
$query_pegawai = $conn->query("SELECT COUNT(*) as total_pegawai FROM pegawai");
$data_pegawai = $query_pegawai->fetch_assoc();
$total_pegawai = $data_pegawai['total_pegawai'];

// Hitung jumlah total perjalanan
$query_perjalanan = $conn->query("SELECT COUNT(*) as total_perjalanan FROM perjalanan");
$data_perjalanan = $query_perjalanan->fetch_assoc();
$total_perjalanan = $data_perjalanan['total_perjalanan'];

// Hitung jumlah total perjalanan kota
$query_perjalanan_kota = $conn->query("SELECT COUNT(*) as total_perjalanan_kota FROM perjalanan_kota");
$data_perjalanan_kota= $query_perjalanan_kota->fetch_assoc();
$total_perjalanan_kota= $data_perjalanan_kota['total_perjalanan_kota'];

// Hitung jumlah total tingkatan perjalanan
$query_tingkatan_perjalanan = $conn->query("SELECT COUNT(*) as total_tingkatan_perjalanan FROM tingkatan_perjalanan");
$data_tingkatan_perjalanan= $query_tingkatan_perjalanan->fetch_assoc();
$total_tingkatan_perjalanan= $data_tingkatan_perjalanan['total_tingkatan_perjalanan'];

// Hitung jumlah total transportasi
$query_transportasi = $conn->query("SELECT COUNT(*) as total_transportasi FROM transportasi");
$data_transportasi = $query_transportasi->fetch_assoc();
$total_transportasi = $data_transportasi['total_transportasi'];

// Hitung jumlah total bbm
$query_bbm = $conn->query("SELECT COUNT(*) as total_bbm FROM bbm");
$data_bbm = $query_bbm->fetch_assoc();
$total_bbm = $data_bbm['total_bbm'];

// Hitung jumlah total sppd
$query_sppd = $conn->query("SELECT COUNT(*) as total_sppd FROM sppd");
$data_sppd = $query_sppd->fetch_assoc();
$total_sppd = $data_sppd['total_sppd'];

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard</title>
        <link href="../page/https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="../page/css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

        <script>
        function updateTime() {
            const now = new Date();
            const date = now.toLocaleDateString('id-ID');
            const time = now.toLocaleTimeString('id-ID');
            document.getElementById('date-time').innerHTML = `<strong>${date}</strong><br>${time}`;
        }
        setInterval(updateTime, 1000);
    </script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-5 d-flex align-items-center" href="#">
        <img src="../gambar/image.png" alt="Logo" width="40" height="40" class="me-1">
        SPPD
    </a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            
<!-- Navbar-->
<ul class="navbar-nav ms-auto me-3 me-lg-4">
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle d-flex align-items-center" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <span class="me-1">Admin</span> <!-- Tulisan "Admin" di kiri -->
            <i class="fas fa-user fa-fw"></i> <!-- Ikon user tetap di kanan -->
        </a>
        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown" style="min-width: 165px;">
            <li class="nav-item dropdown">
                <a class="dropdown-item d-flex justify-content-between align-items-center" href="#" id="settingsDropdown">
                    Settings
                    <i class="fas fa-chevron-down"></i>
                </a>
                <ul class="list-unstyled ps-3" id="settingsMenu" style="display: none; min-width: 165px;">
                    <li><a class="dropdown-item" href="../ganti_password.php">Ganti Password</a></li>
                    <!-- <li><a class="dropdown-item" href="../pengaturan_lainnya.php">Pengaturan Lainnya</a></li> -->
                </ul>
            </li>
            <li><hr class="dropdown-divider" /></li>
            <li><a class="dropdown-item" href="../index.php">Logout</a></li>
        </ul>
    </li>
</ul>
<script>
    document.getElementById("settingsDropdown").addEventListener("click", function(event) {
        event.preventDefault();
        event.stopPropagation(); // Mencegah dropdown utama tertutup
        let settingsMenu = document.getElementById("settingsMenu");
        if (settingsMenu.style.display === "none" || settingsMenu.style.display === "") {
            settingsMenu.style.display = "block";
        } else {
            settingsMenu.style.display = "none";
        }
    });

    document.addEventListener("click", function(event) {
        let settingsMenu = document.getElementById("settingsMenu");
        let settingsDropdown = document.getElementById("settingsDropdown");
        if (!settingsDropdown.contains(event.target) && !settingsMenu.contains(event.target)) {
            settingsMenu.style.display = "none";
        }
    });
</script>
    </nav>

        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <br><br>
                            <a class="nav-link" href="#">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Master Surat
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="../sppd/index.php"> <i class="fa-regular fa-file-lines"></i> &nbsp; Data SPPD</a>
                                    <a class="nav-link" href="../sp/index.php"> <i class="fa-regular fa-file-lines"></i> &nbsp; Data SPT</a>
                                </nav>
                            </div>


                            <!-- menu dinamis -->
                             <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#appx" aria-expanded="false" aria-controls="appx">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-bars"></i></div>Data Master
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="appx" aria-labelledby="headingAppx" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <?php if ($menu->num_rows > 0): ?>
                                        <?php while ($row = $menu->fetch_assoc()) : ?>
                                            <a class="nav-link" href="<?= $row['link_menu'] ?>">
                                                <i class="sb-nav-link-icon <?= $row['icon_menu'] ?>"></i>
                                                <span class="ms-2"><?= $row['nama_menu'] ?></span>
                                            </a>
                                            <?php endwhile; ?>
                                            <?php else: ?>
                                                <a class="nav-link" href="#">
                                                    <i class="sb-nav-link-icon fa fa-exclamation-triangle"></i>
                                                    <span class="ms-2">No Data Master Available</span>
                                                </a>
                                                <?php endif; ?>
                                            </nav>
                                        </div>

                                        <a class="nav-link" href="../sp/index.php">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-file-invoice"></i></div>
                                Laporan
                            </a>
   
                            <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                    
                                </nav>
                            </div>
                            
                        </div>
                    </div>
                    
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Dashboard</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li></ol>

                            <div class="container-fluid">
    <div class="row">
        <!-- Kolom Selamat Datang (60%) -->
        <div class="col-lg-8 col-md-12 mt-4 p-5 bg-primary text-white rounded-3" style="border: 4px solid #ccc;">
            <h2>Selamat Datang</h2>
            <p>Hai <b>Admin</b>, Selamat Datang di Sistem Perjalanan Dinas <br> Silakan klik menu navigasi untuk mengelola website</p>
            <hr style="border: 3px solid white;"> <!-- Garis tebal pembatas -->

            <!-- Kotak-kotak kecil -->
            <div class="row">
                <?php 
                $data = [
                    ["label" => "Golongan", "total" => $total_golongan, "icon" => "fas fa-layer-group", "color" => "bg-success"],
                ["label" => "Jabatan", "total" => $total_jabatan, "icon" => "fa-briefcase", "color" => "bg-info"],
                ["label" => "Pangkat", "total" => $total_pangkat, "icon" => "fa-solid fa-award", "color" => "bg-secondary"],
                ["label" => "Tingkatan", "total" => $total_tingkatan, "icon" => "fa-solid fa-ranking-star", "color" => "bg-warning"],
                ["label" => "Pegawai", "total" => $total_pegawai, "icon" => "fa fa-users", "color" => "bg-danger"],
                ["label" => "Perjalanan", "total" => $total_perjalanan, "icon" => "fa fa-road", "color" => "bg-dark"],
                ["label" => "Perjalanan Kota", "total" => $total_perjalanan_kota, "icon" => "fa fa-map", "color" => "bg-success"],
                ["label" => "Tingkatan Perjalanan", "total" => $total_tingkatan_perjalanan, "icon" => "fa fa-sitemap ", "color" => "bg-info"],
                ["label" => "Transportasi", "total" => $total_transportasi, "icon" => "fa fa-car", "color" => "bg-secondary"],
                ["label" => "BBM", "total" => $total_bbm, "icon" => "fa-solid fa-gas-pump", "color" => "bg-warning"],
                ["label" => "SPPD", "total" => $total_sppd, "icon" => "fa-file-lines", "color" => "bg-danger"],
                
            ];
                foreach ($data as $item) : ?>
                    <div class="col-lg-4 col-md-6 col-sm-6 mb-3">
                        <div class="card text-white <?= $item['color']; ?>">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h5 class="mb-1"><?= $item['label']; ?></h5>
                                        <h3 class="mb-0"><?= $item['total']; ?></h3>
                                    </div>
                                    <i class="fa-solid <?= $item['icon']; ?> fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div><br>

        <!-- Kolom Sistem Informasi (40%) -->
        <div class="col-lg-4 col-md-12 mt-4">
            <div class="card text-center p-3" style="border: 4px solid #ccc; box-shadow: 4px 4px 10px rgba(0, 0, 0, 0.3);">
                <img src="../gambar/dukcapil.jpg" alt="Logo" width="120" class="mx-auto">
                <h4 id="clock">00:00:00</h4>
                <p id="date"></p>
                <hr>
                <p><strong>Nama Sistem:</strong> Aplikasi Perjalanan Dinas</p>
                <p><strong>Instansi:</strong> Dinas DUKCAPIL Boyolali</p>
                <p><strong>Status:</strong> Aktif <span id="activeDate"></span></p>
            </div><br>
        </div>
    </div>
</div><br>

<script>
    function updateClock() {
        const now = new Date();
        document.getElementById('clock').innerText = now.toLocaleTimeString();
        document.getElementById('date').innerText = now.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
        document.getElementById('activeDate').innerText = now.toLocaleDateString('id-ID');
    }
    setInterval(updateClock, 1000);
    updateClock();
</script>

    
                </main>               
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../page/js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="../page/assets/demo/chart-area-demo.js"></script>
        <script src="../page/assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="../page/js/datatables-simple-demo.js"></script>
    </body>
</html>
