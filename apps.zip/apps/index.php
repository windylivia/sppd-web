<!DOCTYPE html>
<?php 
session_start();
include("koneksi.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM login WHERE username = ? AND password = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['id_user'];
        $_SESSION['role'] = $user['role'];

        if ($user['role'] === 'admin') {
            header("Location: dashboard/index.php");
        } else {
            header("Location: dashboard2/index.php");
        }
        exit();
    } else {
        $error = "Username atau password salah!";
    }
}
?>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Login - Sistem SPPD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        body {
            background-color: black;
        }
        .login-container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .card {
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            padding: 20px;
        }
        .card-header {
            background: url('gambar/dukcapil.jpg') no-repeat center;
            background-size: cover;
            color: white;
            text-align: center;
            font-size: 1.5rem;
            font-weight: bold;
            height: 150px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        .card-header::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
        }
        .card-header span {
            position: relative;
            z-index: 1;
        }
        .register-link {
            text-align: left;
            font-size: 14px;
        }
        .register-link a {
            color: #007bff;
            text-decoration: none;
        }
        .register-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container login-container">
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header"><span>SISTEM SPPD</span></div>
                <div class="card-body">
                    <form method="POST" action="">
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo $error; ?>
                            </div>
                        <?php endif; ?>
                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <div class="form-floating flex-grow-1">
                                <input class="form-control" id="username" type="text" name="username" placeholder="Username" required />
                                <label for="username">Nama Pengguna</label>
                            </div>
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <div class="form-floating flex-grow-1">
                                <input class="form-control" id="password" type="password" name="password" placeholder="Password" required />
                                <label for="password">Kata Sandi</label>
                            </div>
                        </div>
                        <div class="d-flex flex-column align-items-center mt-3">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fa fa-sign-in-alt me-2"></i> Masuk
                            </button>
                        </div>
                        <div class="register-link mt-3">
                            <a href="register.php">Belum punya akun? Daftar</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>
