<?php
include("../koneksi.php");

$menu = $conn->query("SELECT * FROM menu");

// Ambil data pegawai dan tingkatan
$pegawai = $conn->query("SELECT * FROM pegawai");
$tingkatan = $conn->query("SELECT * FROM tingkatan");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_pegawai = $_POST['id_pegawai'];
    $id_tingkatan = $_POST['id_tingkatan'];
    $luar_solo = $_POST['luar_solo'];
    $dalam_solo = $_POST['dalam_solo'];
    $kurang_8_jam = $_POST['kurang_8_jam'];
    $lebih_8_jam = $_POST['lebih_8_jam'];

    // Insert ke database
    $conn->query("INSERT INTO tingkatan_perjalanan (id_pegawai, id_tingkatan, luar_solo, dalam_solo, kurang_8_jam, lebih_8_jam)
                  VALUES ('$id_pegawai', '$id_tingkatan',  '$luar_solo', '$dalam_solo', '$kurang_8_jam', '$lebih_8_jam')");

    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Tambah Tingkatan Perjalanan</title>
        <link href="../page/https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="../page/css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-5" href="../index.php">SISDUK</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#!">Settings</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="../index.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <br><br>
                            <a class="nav-link" href="../dashboard/index.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Master Surat
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="../sppd/index.php"> <i class="fa-regular fa-file-lines"></i> &nbsp;Data SPPD</a>
                                    <a class="nav-link" href="../sp/index.php"> <i class="fa-regular fa-file-lines"></i> &nbsp;Data SPT</a>
                                </nav>
                            </div>
                            
                            <!-- menu dinamis -->
                             <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#appx" aria-expanded="false" aria-controls="appx">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-bars"></i></div>Data Master
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="appx" aria-labelledby="headingAppx" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <?php if ($menu->num_rows > 0): ?>
                                        <?php while ($row = $menu->fetch_assoc()) : ?>
                                            <a class="nav-link" href="<?= $row['link_menu'] ?>">
                                                <i class="sb-nav-link-icon <?= $row['icon_menu'] ?>"></i>
                                                <span class="ms-2"><?= $row['nama_menu'] ?></span>
                                            </a>
                                            <?php endwhile; ?>
                                            <?php else: ?>
                                                <a class="nav-link" href="#">
                                                    <i class="sb-nav-link-icon fa fa-exclamation-triangle"></i>
                                                    <span class="ms-2">No Data Master Available</span>
                                                </a>
                                                <?php endif; ?>
                                            </nav>
                                        </div>

                            <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                    
                                </nav>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Tingkatan Perjalanan</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="../dashboard">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="index.php">Tingkatan Perjalanan</a></li>
                            <li class="breadcrumb-item active">Tambah Tingkatan Perjalanan</li>
                        </ol>
                        
                        <!-- Form Section -->
                    <div class="container mt-5">
                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <div class="card shadow-sm border-dark">
                                    <div class="card-header bg-dark text-white text-center">
                                        <h5>Tambah Tingkatan Perjalanan</h5>
                                    </div>
                                    <div class="card-body">
                        <form method="POST">
                            <!-- Baris pertama -->
                            <div class="row">
                                <!-- Pegawai -->
                                <div class="col-md-6">
                                    <label for="id_pegawai" class="form-label">Nama Pegawai</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                                        <select class="form-select border-info" id="id_pegawai" name="id_pegawai" required>
                                            <option value="">--Pilih Pegawai--</option>
                                            <?php while ($row = $pegawai->fetch_assoc()) : ?>
                                                <option value="<?= $row['id_pegawai'] ?>"><?= $row['nama'] ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                </div>
                                <!-- Tingkatan -->
                                <div class="col-md-6">
                                    <label for="id_tingkatan" class="form-label">Tingkatan</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fa-solid fa-ranking-star"></i></span>
                                        <select class="form-select border-info" id="id_tingkatan" name="id_tingkatan" required>
                                            <option value="">--Pilih Tingkatan--</option>
                                            <?php while ($row = $tingkatan->fetch_assoc()) : ?>
                                                <option value="<?= $row['id_tingkatan'] ?>"><?= $row['tingkatan'] ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Baris kedua -->
                            <div class="row mt-2">
                                <!-- Luar Solo -->
                                <div class="col-md-6">
                                    <label for="luar_solo" class="form-label">Luar Solo</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                                        <input type="text" class="form-control border-info" name="luar_solo" id="luar_solo" autocomplete="off" required>
                                    </div>
                                </div>
                                <!-- Dalam Solo -->
                                <div class="col-md-6">
                                    <label for="dalam_solo" class="form-label">Dalam Solo</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                                        <input type="text" class="form-control border-info" name="dalam_solo" id="dalam_solo" autocomplete="off" required>
                                    </div>
                                </div>
                            </div>

                            <!-- Baris ketiga -->
                            <div class="row mt-2">
                                <!-- Kurang 8 Jam -->
                                <div class="col-md-6">
                                    <label for="kurang_8_jam" class="form-label">Kurang 8 Jam</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-clock"></i></span>
                                        <input type="text" class="form-control border-info" name="kurang_8_jam" id="kurang_8_jam" autocomplete="off" required>
                                    </div>
                                </div>
                                <!-- Lebih 8 Jam -->
                                <div class="col-md-6">
                                    <label for="lebih_8_jam" class="form-label">Lebih 8 Jam</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-clock"></i></span>
                                        <input type="text" class="form-control border-info" name="lebih_8_jam" id="lebih_8_jam" autocomplete="off" required>
                                    </div>
                                </div>
                            </div>

                            <!-- Tombol -->
                            <div class="d-flex justify-content-between mt-4">
                                <a href="index.php" class="btn btn-secondary">
                                    <i class="fa fa-arrow-left me-2"></i>Kembali
                                </a>
                                <button type="submit" name="add" class="btn btn-success">
                                    <i class="fa fa-save me-2"></i>Simpan
                                </button>
                            </div>
                        </form>
                    </div>

            </div>
        </div>
    </div>
</div>
<!-- End Form Section -->

<br><br><br>


                       
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../page/js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="../page/assets/demo/chart-area-demo.js"></script>
        <script src="../page/assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="../page/js/datatables-simple-demo.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    </body>
</html>
