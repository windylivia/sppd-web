<?php
include('../koneksi.php');

// Ambil ID dari URL
$id = $_GET['id'];

// Hapus data berdasarkan ID
$conn->query("DELETE FROM tingkatan_perjalanan WHERE id_tingkatan_perjalanan = $id");

header("Location: index.php");
?>
