<?php
include("../koneksi.php");

$id_golongan = $_GET['id'];

$query = "DELETE FROM golongan WHERE id_golongan = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_golongan);
$stmt->execute();

header("Location: index.php");
?>
