<?php
include("../koneksi.php");

$id_pangkat = $_GET['id'];

$query = "DELETE FROM pangkat WHERE id_pangkat = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_pangkat);
$stmt->execute();

header("Location: index.php");
?>
