<?php
include("../Koneksi.php");

$id_bbm = $_GET['id'];

$query = "DELETE FROM bbm WHERE id_bbm = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_bbm);
$stmt->execute();

header("Location: index.php");
?>