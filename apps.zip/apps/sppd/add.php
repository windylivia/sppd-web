<?php
include("../koneksi.php");

date_default_timezone_set('Asia/Jakarta');

$menu = $conn->query("SELECT * FROM menu");

// Ambil Data pangkat dan Jabatan untuk Dropdown
$pegawai = $conn->query("SELECT * FROM pegawai");
$transportasi = $conn->query("SELECT * FROM transportasi");
$bbm = $conn->query("SELECT * FROM bbm");

// Proses Tambah Data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_pegawai = $_POST['id_pegawai'];
    $no_sppd = $_POST['no_sppd'];
    $pejabat_perintah = $_POST['pejabat_perintah'];
    $tempat_tujuan = $_POST['tempat_tujuan'];
    $maksud_perjalanan = $_POST['maksud_perjalanan'];
    $id_transportasi = $_POST['id_transportasi'];
    $id_bbm = $_POST['id_bbm'];
    $lama_perjalanan = $_POST['lama_perjalanan'];
    $tanggal_berangkat = $_POST['tanggal_berangkat'];
    $tanggal_kembali = $_POST['tanggal_kembali'];
    $instansi = $_POST['instansi'];
    $mata_anggaran = $_POST['mata_anggaran'];
    $keterangan_lain = $_POST['keterangan_lain'];
    $tgl_input = date('Y-m-d H:i:s');

    // Insert ke database
    $conn->query("INSERT INTO sppd (id_pegawai, no_sppd, pejabat_perintah, tempat_tujuan, maksud_perjalanan, id_transportasi, id_bbm, lama_perjalanan, tanggal_berangkat, tanggal_kembali, instansi, mata_anggaran, keterangan_lain, tgl_input)
                  VALUES ('$id_pegawai', '$no_sppd',  '$pejabat_perintah', '$tempat_tujuan', '$maksud_perjalanan', '$id_transportasi', '$id_bbm', '$lama_perjalanan', '$tanggal_berangkat', '$tanggal_kembali', '$instansi', '$mata_anggaran', '$keterangan_lain', '$tgl_input')");

    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Tambah SPPD</title>
        <link href="../page/https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="../page/css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    </head>
    
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-5" href="../index.php">SISDUK</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                </div>
            </form>
            <!-- Navbar-->

            
         <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#!">Settings</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="../index.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <br><br>
                            <a class="nav-link" href="../dashboard/index.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Master Surat
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="../sppd/index.php"> <i class="fa-regular fa-file-lines"></i> &nbsp;Data SPPD</a>
                                    <a class="nav-link" href="../sp/index.php"> <i class="fa-regular fa-file-lines"></i> &nbsp;Data SPT</a>
                                </nav>
                            </div>
                            
                            <!-- menu dinamis -->
                             <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#appx" aria-expanded="false" aria-controls="appx">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-bars"></i></div>Data Master
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="appx" aria-labelledby="headingAppx" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <?php if ($menu->num_rows > 0): ?>
                                        <?php while ($row = $menu->fetch_assoc()) : ?>
                                            <a class="nav-link" href="<?= $row['link_menu'] ?>">
                                                <i class="sb-nav-link-icon <?= $row['icon_menu'] ?>"></i>
                                                <span class="ms-2"><?= $row['nama_menu'] ?></span>
                                            </a>
                                            <?php endwhile; ?>
                                            <?php else: ?>
                                                <a class="nav-link" href="#">
                                                    <i class="sb-nav-link-icon fa fa-exclamation-triangle"></i>
                                                    <span class="ms-2">No Data Master Available</span>
                                                </a>
                                                <?php endif; ?>
                                            </nav>
                                        </div>

                            <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                    
                                </nav>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">SPPD</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="../dashboard">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="index.php">SPPD</a></li>
                            <li class="breadcrumb-item active">Tambah SPPD</li>
   
                        </ol>
                        
<!-- Form Section -->
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm border-dark">
                <div class="card-header bg-dark text-white text-center">
                    <h5>Tambah SPPD</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="row">
                            <!-- Pegawai -->
                            <div class="col-md-6">
                                <label for="id_pegawai" class="form-label">Nama Pegawai</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fa fa-user"></i></span>
                                    <select class="form-select border-info" id="id_pegawai" name="id_pegawai" required>
                                        <option value="">--Pilih Pegawai--</option>
                                        <?php while ($row = $pegawai->fetch_assoc()) : ?>
                                            <option value="<?= $row['id_pegawai'] ?>"><?= $row['nama'] ?></option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <label for="no_sppd" class="form-label">No SPPD</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fa fa-file-alt"></i></span>
                                    <input type="text" class="form-control border-info" id="no_sppd" name="no_sppd" placeholder="Masukkan Nomor" autocomplete="off" required>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <!-- Pejabat Pembuat Komitmen -->
                            <div class="col-md-6">
                                <label for="pejabat_perintah" class="form-label">Pejabat Pembuat Komitmen</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fa fa-user-tie"></i></span>
                                    <input type="text" class="form-control border-info" id="pejabat_perintah" name="pejabat_perintah" placeholder="Masukkan Nama" autocomplete="off" required>
                                </div>
                            </div>

                            <!-- Tempat Tujuan -->
                            <div class="col-md-6">
                                <label for="tempat_tujuan" class="form-label">Tempat Tujuan</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fa fa-map-marker-alt"></i></span>
                                    <input type="text" class="form-control border-info" id="tempat_tujuan" name="tempat_tujuan" placeholder="Masukkan Tempat" autocomplete="off" required>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <!-- Maksud Perjalanan -->
                            <div class="col-md-6">
                                <label for="maksud_perjalanan" class="form-label">Maksud Perjalanan Dinas</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fa fa-briefcase"></i></span>
                                    <input type="text" class="form-control border-info" id="maksud_perjalanan" name="maksud_perjalanan" placeholder="Masukkan Maksud Perjalanan" autocomplete="off" required>
                                </div>
                            </div>

                            <!-- Alat Transportasi -->
                            <div class="col-md-6">
                                <label for="id_transportasi" class="form-label">Alat Transportasi</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fa fa-bus"></i></span>
                                    <select class="form-select border-info" id="id_transportasi" name="id_transportasi" required>
                                        <option value="">--Pilih Transportasi--</option>
                                        <?php while ($row = $transportasi->fetch_assoc()) : ?>
                                            <option value="<?= $row['id_transportasi'] ?>"><?= $row['transportasi'] ?></option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <!-- Kecamatan -->
                            <div class="col-md-6">
                                <label for="id_bbm" class="form-label">Kecamatan</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fa fa-city"></i></span>
                                    <select class="form-select border-info" id="id_bbm" name="id_bbm" required>
                                        <option value="">--Pilih Kecamatan--</option>
                                        <?php while ($row = $bbm->fetch_assoc()) : ?>
                                            <option value="<?= $row['id_bbm'] ?>"><?= $row['kecamatan'] ?></option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                            </div>

                            <!-- Lama Perjalanan -->
                            <div class="col-md-6">
                                <label for="lama_perjalanan" class="form-label">Lama Perjalanan</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fa fa-clock"></i></span>
                                    <input type="text" class="form-control border-info" id="lama_perjalanan" name="lama_perjalanan" placeholder="Masukkan Lama Perjalanan" autocomplete="off" required>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <!-- Tanggal Berangkat -->
                            <div class="col-md-6">
                                <label for="tanggal_berangkat" class="form-label">Tanggal Berangkat</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fa fa-calendar-alt"></i></span>
                                    <input type="date" class="form-control border-info" id="tanggal_berangkat" name="tanggal_berangkat" autocomplete="off" required>
                                </div>
                            </div>

                            <!-- Tanggal Kembali -->
                            <div class="col-md-6">
                                <label for="tanggal_kembali" class="form-label">Tanggal Kembali</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fa fa-calendar-check"></i></span>
                                    <input type="date" class="form-control border-info" id="tanggal_kembali" name="tanggal_kembali" autocomplete="off" required>
                                    <input type="hidden" id="tgl_input" name="tgl_input" value="<?= date('Y-m-d H:i:s') ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <!-- Keterangan Lain -->
                            <div class="col-md-12">
                                <label for="keterangan_lain" class="form-label">Keterangan Lain-Lain</label>
                                <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-info-circle"></i></span>
                                <textarea class="form-control border-info" id="keterangan_lain" name="keterangan_lain" placeholder="Masukkan Keterangan Lain" autocomplete="off" required></textarea>
                            </div>
                        </div>
                        </div>

                        <div class="d-flex justify-content-between mt-4">
                            <a href="index.php" class="btn btn-secondary">
                                <i class="fa fa-arrow-left me-2"></i>Kembali
                            </a>
                            <button type="submit" name="add" class="btn btn-success">
                                <i class="fa fa-save me-2"></i>Simpan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><br><br>

<!-- End Form Section -->
             
            </div>
        </div>
        <script>
document.getElementById('tanggal_berangkat').addEventListener('change', hitungLamaPerjalanan);
document.getElementById('tanggal_kembali').addEventListener('change', hitungLamaPerjalanan);

function hitungLamaPerjalanan() {
    let tglBerangkat = document.getElementById('tanggal_berangkat').value;
    let tglKembali = document.getElementById('tanggal_kembali').value;
    let lamaPerjalananInput = document.getElementById('lama_perjalanan');

    if (tglBerangkat && tglKembali) {
        let startDate = new Date(tglBerangkat);
        let endDate = new Date(tglKembali);
        let selisih = (endDate - startDate) / (1000 * 60 * 60 * 24); // Konversi ke hari

        if (selisih >= 0) {
            lamaPerjalananInput.value = selisih + " hari";
        } else {
            lamaPerjalananInput.value = "Tanggal tidak valid";
        }
    }
}
</script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../page/js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="../page/assets/demo/chart-area-demo.js"></script>
        <script src="../page/assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="../page/js/datatables-simple-demo.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    </body>
</html>
