<?php
include("../koneksi.php");

$id_sppd = $_GET['id'];

$query = "DELETE FROM sppd WHERE id_sppd = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $no_sppd);
$stmt->execute();

header("Location: index.php");
?>
