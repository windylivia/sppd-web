<!-- <?php
include("../koneksi.php");
?> -->
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Surat Perjalanan Dinas</title>
    <!-- <link rel="stylesheet" href="styles.css"> -->

<style>

     /* Mengatur tampilan body halaman */
 body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 20px;
  background-color: #f9f9f9;
}

/* Mengatur kontainer utama surat */
.container {
  background-color: #fff;
  padding: 20px;
  border: 1px solid #ccc;
  max-width: 800px;
  margin: auto;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  position: relative;
  min-height: 1250px; /* Memperpanjang panjang kertas */
}

/* Mengatur header surat */
.header {
  text-align: center;
  margin-bottom: 20px;
  position: relative;
}

.header img {
  width: 80px;
  height: auto;
  position: absolute;
  top: 0;
  left: 20px;
}

.header h1 {
  margin: 5px 0;
  font-size: 18px;
  text-transform: uppercase;
}

.header p {
  margin: 0;
  font-size: 14px;
}

h2 {
  text-align: center;
  font-size: 18px;
  margin-top: 30px;
  text-decoration: underline;
}
h2 span {
  display: block;
  font-size: 16px;
  margin-top: 5px;
  
}

/* Menambahkan garis horizontal pada bagian header */
.lines {
  margin-top: 10px;
}

.line-thin {
  border-top: 1px solid black;
}

.line-thick {
  border-top: 3px solid black;
  margin-top: 2px;
}

/* Mengatur tampilan nomor dan lembar di sebelah kanan */
.info {
  text-align: left; /* Tetap rata kiri */
  float: right; /* Posisikan di kanan */
  font-size: 14px;
  margin-bottom: 20px;
}

/* Mengatur tampilan tabel informasi perjalanan dinas */
table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 20px;
}

table, th, td {
  border: 1px solid black;
}

th, td {
  padding: 8px;
  text-align: left;
  font-size: 14px;
}

/* Mengatur tampilan bagian tanda tangan */
.signature {
  text-align: center;
  margin-top: 30px;
  position: relative;
  float: right;
  width: 300px;
  left: -80px; /* Menggeser tanda tangan ke kiri */
}

.signature p {
  margin: 5px 0;
}

</style>

</head>
<body>
    <div class="container">
        <!-- Bagian Header Surat -->
        <div class="header">
            <img src="image.jpeg" alt="Logo dukcapil">
            <h1>Pemerintah Kabupaten Boyolali</h1>
            <h1>Dinas Kependudukan dan Pencatatan Sipil</h1>
            <p>Kompleks Perkantoran Terpadu, Jl. Merdeka Timur, Kemiri, Kec. Mojosongo, Kabupaten Boyolali, Jawa Tengah 57482 <p>Telp./Fax. (0276) 322130</p></p>
            <p>Website: http://disdukcapil.boyolali.go.id</p>
            <div class="lines">
                <div class="line-thin"></div>
                <div class="line-thick"></div>
            </div>
        </div>

        <!-- Bagian Informasi Nomor dan Lembar -->
        <div class="info">
            <p>Lembar ke: 1 (satu)</p>
            <p>Nomor: 090/530/DISPENDUKCAPIL</p>
        </div>  <br><br><br><br>      

        <!-- Judul Surat -->
        <h2 style="text-align: center;">SURAT PERINTAH PERJALANAN DINAS
    <span>(SPPD)</span></h2>

        <!-- Tabel Informasi Perjalanan Dinas -->
        <table>
            <tr>
                <td>1.</td>
                <td>Pejabat yang memberi perintah</td>
                <td>Kepala Dinas Kependudukan dan Pencatatan Sipil</td>
            </tr>
            <tr>
                <td>2.</td>
                <td>Nama Pegawai yang diperintah</td>
                <td>..........</td>
            </tr>
            <tr>
                <td rowspan="3">3.</td>
                <td>a. Pangkat dan Golongan</td>
                <td>Pembina / IV-a</td>
            </tr>
            <tr>
                <td>b. Jabatan</td>
                <td>Kabid Pelayanan Pendaftaran Penduduk</td>
            </tr>
            <tr>
                <td>c. Tingkat menurut peraturan perjalanan</td>
                <td>Perjalanan dinas dalam kota/dalam daerah</td>
            </tr>
            <tr>
                <td>4.</td>
                <td>Maksud Perjalanan Dinas</td>
                <td>Pelayanan Pendaftaran Identitas Kependudukan Digital (IKD) </td>
            </tr>
            <tr>
                <td>5.</td>
                <td>Alat angkut yang dipergunakan</td>
                <td>Dispendukcapil Kab. Boyolali</td>
            </tr>
            <tr>
                <td rowspan="2">6.</td>
                <td>a. Tempat berangkat</td>
                <td>Kabupaten Boyolali</td>
            </tr>
            <tr>
                <td>b. Tempat tujuan</td>
                <td>Lapangan Sambongsari</td>
            </tr>
            <tr>
                <td>7.</td>
                <td>Lamanya perjalanan dinas</td>
                <td>26 Februari 2023</td>
            </tr>
            <tr>
                <td>8.</td>
                <td>Pengikut</td>
                <td>
                    <ul>
                        <li>......</li>
                        <li>.........</li>
                        <li>..........</li>
                        <li>.........</li>
                        <li>..........</li>

                    </ul>
                </td>
            </tr>
            <tr>
                <td rowspan="2">9.</td>
                <td>a. Instansi</td>
                <td>Dispendukcapil Kab. Boyolali</td>
            </tr>
            <tr>
                <td>b. Mata Anggaran</td>
                <td>APBD Kab. Boyolali</td>
            </tr>
            <tr>
                <td>10.</td>
                <td>Keterangan lain-lain</td>
                <td></td>
            </tr>
        </table>

        <!-- Bagian Tanda Tangan -->
        <div class="signature">
            <p>Boyolali, 25 Februari 2024</p>
            <p>Kepala Dinas Kependudukan dan Pencatatan Sipil</p>
            <p>Kabupaten Boyolali</p>
            <br><br><br><br>
            <p><strong>....................</strong></p>
            <p>Pembina Tingkat I</p>
            <p>NIP. 197404041998032007</p>
        </div>
    </div>
</body>
</html>

<script>
    // window.print();  
</script>