<?php
include("../Koneksi.php");

$id_pegawai = $_GET['id'];

$query = "DELETE FROM pegawai WHERE id_pegawai = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_pegawai);
$stmt->execute();

header("Location: index.php");
?>