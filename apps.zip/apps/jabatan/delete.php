<?php
include("../koneksi.php");

$id_jabatan = $_GET['id'];

$query = "DELETE FROM jabatan WHERE id_jabatan = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_jabatan);
$stmt->execute();

header("Location: index.php");
?>
