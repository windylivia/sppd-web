<?php
include("../koneksi.php");

$id_transportasi = $_GET['id'];

$query = "DELETE FROM transportasi WHERE id_transportasi = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_transportasi);
$stmt->execute();

header("Location: index.php");
?>
