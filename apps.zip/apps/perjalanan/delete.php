<?php
include("../koneksi.php");

$id_perjalanan = $_GET['id'];

$query = "DELETE FROM perjalanan WHERE id_perjalanan = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_perjalanan);
$stmt->execute();

header("Location: index.php");
?>
