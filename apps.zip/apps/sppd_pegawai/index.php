<?php
include("../koneksi.php");

date_default_timezone_set('Asia/Jakarta');

// Ambil data menu
$menu = $conn->query("SELECT * FROM menu");

// Filter tanggal
$filterQuery = "";


// Cek ada input tanggal 
if (isset($_GET['start_date']) && !empty($_GET['start_date'])) {
    $start_date = $_GET['start_date'];
    $end_date = isset($_GET['end_date']) && !empty($_GET['end_date']) ? $_GET['end_date'] : $start_date;

    if ($start_date == $end_date) {
        // Jika hanya satu tanggal yang dipilih
        $filterQuery = "WHERE DATE(sppd.tgl_input) = '$start_date'";
    } else {
        // Jika rentang tanggal dipilih
        $filterQuery = "WHERE DATE(sppd.tgl_input) BETWEEN '$start_date' AND '$end_date'";
    }
} else {
    // Default: hanya menampilkan data hari ini
    $filterQuery = "WHERE DATE(sppd.tgl_input) = CURDATE()";
}

// Ambil data SPPD dengan filter
$result = $conn->query("SELECT sppd.*, pegawai.nama AS nama_pegawai, transportasi.transportasi AS transportasi, bbm.kecamatan AS kecamatan
                        FROM sppd
                        JOIN pegawai ON sppd.id_pegawai = pegawai.id_pegawai
                        JOIN transportasi ON sppd.id_transportasi = transportasi.id_transportasi
                        JOIN bbm ON sppd.id_bbm = bbm.id_bbm
                        $filterQuery");
?>

<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>SPPD</title>
        <link href="../page/https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="../page/css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-5" href="#">SISDUK</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#!">Settings</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="../index.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <br><br>
                            <a class="nav-link" href="../dashboard2">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Master Surat
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="../sppd_pegawai/index.php"> <i class="fa-regular fa-file-lines"></i> &nbsp;Data SPPD</a>
                                    <a class="nav-link" href="../sp_pegawai/index.php"> <i class="fa-regular fa-file-lines"></i> &nbsp;Data SPT</a>
                                </nav>
                            </div>
                        
                           
                            <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                     </nav>
                                    </div>
                                </div>
                            </div>
                        </nav>
                    </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">SPPD</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="../dashboard2">Dashboard</a></li>
                            <li class="breadcrumb-item active">SPPD</li>
                        </ol>

                        <!-- table -->
                         <div class="card mb-4">
                         <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
    <!-- Form Filter Tanggal -->
    <form method="GET" class="d-flex flex-wrap align-items-center justify-content-center gap-2 w-100">
    <div class="d-flex flex-column flex-sm-row align-items-center gap-2">
        <label for="start_date" class="fw-bold">Dari:</label>
        <input type="date" name="start_date" id="start_date" class="form-control form-control-sm" style="width: 140px;"
            value="<?= isset($_GET['start_date']) ? $_GET['start_date'] : '' ?>">
    </div>

    <div class="d-flex flex-column flex-sm-row align-items-center gap-2">
        <label for="end_date" class="fw-bold">Sampai:</label>
        <input type="date" name="end_date" id="end_date" class="form-control form-control-sm" style="width: 140px;"
            value="<?= isset($_GET['end_date']) ? $_GET['end_date'] : '' ?>">
    </div>

    <div class="d-flex gap-2 justify-content-center w-100">
        <!-- Tombol Cari -->
        <button type="submit" class="btn btn-primary btn-sm">Cari</button>

        <!-- Tombol reset -->
        <a href="index.php" class="btn btn-secondary btn-sm">Reset</a>
    </div>
</form>
</div>

                            <div class="card-body">
                                <table id="datatablesSimple" class="custom-table">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Pegawai</th>
                                            <th>No SPPD</th>
                                            <th>Tugas</th>
                                            <th>Tujuan</th>
                                            <th>Tanggal</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 1; while ($row = $result->fetch_assoc()) : ?>
                                        <tr>
                                            <td><?= $no++; ?></td>
                                            <td><?= $row['nama_pegawai'] ?></td>
                                            <td><?= $row['no_sppd'] ?></td>
                                            <td><?= $row['maksud_perjalanan'] ?></td>
                                            <td><?= $row['tempat_tujuan'] ?></td>
                                            <td><?= $row['tgl_input'] ?></td>
                                            <td style="text-align: center; vertical-align: middle;">
                                            <a href="lihat.php?id=<?= $row['id_sppd'] ?>" class="btn btn-info btn-sm">
                                                <i class="fa-solid fa-eye"></i> Lihat
                                            </a>
                                            <a href="cetak.php?id=<?= $row['id_sppd'] ?>" class="btn btn-success btn-sm">
                                                <i class="fa-solid fa-print"></i> Cetak
                                            </a>
                                        </td>

                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- end tabel-->
                        </main>
                        </div>
                    </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../page/js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="../page/assets/demo/chart-area-demo.js"></script>
        <script src="../page/assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="../page/js/datatables-simple-demo.js"></script>
        
    </body>
</html>
