<?php
include("../koneksi.php");

if (isset($_GET['id'])) {
    $id_sppd = $_GET['id'];

    // Query untuk mengambil data dari sppd dan pegawai beserta pangkat, golongan, dan jabatan
    $query = $conn->query("SELECT sppd.*, pegawai.nama AS nama_pegawai, pegawai.nip, 
               pangkat.pangkat, golongan.golongan, jabatan.jabatan, 
               transportasi.transportasi AS alat_transportasi
        FROM sppd
        JOIN pegawai ON sppd.id_pegawai = pegawai.id_pegawai
        LEFT JOIN pangkat ON pegawai.id_pangkat = pangkat.id_pangkat
        LEFT JOIN golongan ON pegawai.id_golongan = golongan.id_golongan
        LEFT JOIN jabatan ON pegawai.id_jabatan = jabatan.id_jabatan
        JOIN transportasi ON sppd.id_transportasi = transportasi.id_transportasi
        WHERE sppd.id_sppd = '$id_sppd'");

    if ($query->num_rows > 0) {
        $data = $query->fetch_assoc();
    } else {
        echo "Data tidak ditemukan.";
        exit;
    }
} else {
    echo "ID tidak valid.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak SPPD</title>
</head>
<body>


<table width="100%" cellpadding="5">
    <tr>
        <td width="10%"><img src="../gambar/image.jpeg" alt="Logo Boyolali" width="100%"></td>
        <td width="90%" align="center">
            <b>PEMERINTAH KABUPATEN BOYOLALI</b><br>
            <b>DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL</b><br>
            Kompleks Perkantoran Terpadu Kab. Boyolali <br>
            Jl. Merdeka Timur, Siswodipuran Boyolali 57311, Jawa Tengah<br>
            Telp./Fax. (0276) 322130, 
            Website: <a href="http://disdukcapil.boyolali.go.id">http://disdukcapil.boyolali.go.id</a>
        </td>
    </tr>
</table>

<hr style="border: 1px solid black; margin: 5px 0;">
<hr style="border: 3px solid black; margin: 5px 0;">

<table style="font-size:12px;" width="100%" cellspacing="0" cellpadding="5">
    <tr>
        <td width="70%"></td>
        <td width="30%">
            <table width="100%" cellspacing="0" cellpadding="5">
                <tr>
                    <td><b>Lembar ke:</b> 1 (satu)</td>
                </tr>
                <tr>
                    <td><b>Nomor:</b> <?= $data['no_sppd'] ?></td>
                </tr>
            </table>
        </td>
    </tr>
</table>

<br>
<center><b>SURAT PERINTAH PERJALANAN DINAS (SPPD)</b></center>

<table style="font-size:12px;" border="1" width="100%" cellspacing="0" cellpadding="5">
    <tr>
        <td width="5%">1</td>
        <td width="30%">Pejabat Pembuat Komitmen</td>
        <td><?= $data['pejabat_perintah'] ?></td>
    </tr>
    <tr>
        <td>2</td>
        <td>Nama/NIP Pegawai yang melaksanakan perintah</td>
        <td><?= $data['nama_pegawai'] ?> / <?= $data['nip'] ?></td>
    </tr>
    <tr>
        <td rowspan="3">3</td>
        <td>a. Pangkat dan Golongan</td>
        <td><?= $data['pangkat'] ?> / <?= $data['golongan'] ?></td>
    </tr>
    <tr>
        <td>b. Jabatan/Instansi</td>
        <td><?= $data['jabatan'] ?></td>
    </tr>
    <tr>
        <td>c. Tingkat Biaya Perjalanan Dinas</td>
        <td>Perjalanan dinas dalam kota/dalam daerah</td>
    </tr>
    <tr>
        <td>4</td>
        <td>Maksud Perjalanan Dinas</td>
        <td><?= $data['maksud_perjalanan'] ?></td>
    </tr>
    <tr>
        <td>5</td>
        <td>Alat angkut yang dipergunakan</td>
        <td><?= $data['alat_transportasi'] ?></td>
    </tr>
    <tr>
        <td rowspan="2">6</td>
        <td>a. Tempat berangkat</td>
        <td>Boyolali</td>
    </tr>
    <tr>
        <td>b. Tempat Tujuan</td>
        <td><?= $data['tempat_tujuan'] ?></td>
    </tr>
    <tr>
        <td rowspan="3">7</td>
        <td>a. Lamanya Perjalanan Dinas</td>
        <td><?= $data['lama_perjalanan'] ?> hari</td>
    </tr>
    <tr>
        <td>b. Tanggal berangkat</td>
        <td><?= date('d F Y', strtotime($data['tanggal_berangkat'])) ?></td>
    </tr>
    <tr>
        <td>c. Tanggal harus kembali/tiba di tempat baru</td>
        <td><?= date('d F Y', strtotime($data['tanggal_kembali'])) ?></td>
    </tr>
    <tr>
        <td>8</td>
        <td>Pengikut: Nama</td>
        <td>-</td>
    </tr>
    <tr>
        <td rowspan="2">9</td>
        <td>Pembebanan Anggaran:<br>a. SKPD</td>
        <td><?= $data['instansi'] ?></td>
    </tr>
    <tr>
        <td>b. Kode Rekening</td>
        <td><?= $data['mata_anggaran'] ?></td>
    </tr>
    <tr>
        <td>10</td>
        <td>Keterangan lain-lain</td>
        <td><?= $data['keterangan_lain'] ?></td>
    </tr>
</table>

<br><br>

<table width="100%">
    <tr>
        <td width="60%"></td>
        <td align="center">
            Ditetapkan di Boyolali<br>
            pada tanggal <?= date('d F Y', strtotime($data['tgl_input'])) ?><br>
            Kepala Dinas Kependudukan dan Pencatatan Sipil<br>
            Kabupaten Boyolali<br><br><br><br><br>
            <b>Drs. Susilo Hartono</b><br>
            Pembina Utama Muda<br>
            NIP. 197404041998032007
        </td>
    </tr>
</table>

</body>
</html>

