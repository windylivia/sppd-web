<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Surat Perintah</title>
</head>
<body>

<table width="100%" cellspacing="0" cellpadding="5">
    <tr>
        <td width="15%"><img src="../sppd/image.jpeg" alt="Logo Boyolali" width="100%"></td>
        <td width="85%" align="center">
            <b>PEMERINTAH KABUPATEN BOYOLALI</b><br>
            <b>DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL</b><br>
            Kompleks Perkantoran Terpadu Kab. Boyolali<br>
            Jl. Merdeka Timur, Ssiswodipuran Boyolali 57311, Jawa Tengah<br>
            Telp. (0276) 322463, Fax. (0276) 322463<br>
            E-mail: <i>dispendukcapil.boyolali@gmail.com</i>, Website: <a href="#">dispendukcapil.boyolali.go.id</a>
        </td>
    </tr>
</table>

<hr>

<table width="100%" cellspacing="0" cellpadding="5">
    <tr>
        <td align="center"><b>SURAT PERINTAH</b></td>
    </tr>
    <tr>
        <td align="center">NOMOR: 800.1.1.1/3915/4.9/2024</td>
    </tr>
</table>

<table width="100%" cellspacing="0" cellpadding="5">
    <tr>
    <td width="20%" valign="top">Menimbang</td>
        <td width="2%" valign="top">:</td>
        <td align="justify">
            a. Bahwa dalam rangka tertib administrasi dalam pelaksanaan kegiatan sosialisasi dan Bimbingan Teknis Administrasi Kependudukan, perlu dibentuk susunan kepanitiaan.<br><br>
            b. Bahwa berdasarkan pertimbangan tersebut, maka perlu mengeluarkan Surat Perintah ini.

        </td>
    </tr>
    <tr>
    <td valign="top">Dasar</td>
    <td valign="top">:</td>
    <td align="justify">DPA Dinas Kependudukan dan Pencatatan Sipil Kab. Boyolali.</td>
    </tr>
    <tr>
    <td colspan="3"align="center"><br>Memberi Perintah:</td>
    </tr>
    <tr>
    <td valign="top">Kepada</td>
    <td valign="top">:</td>
    <td align="justify">Nama – nama sebagaimana tersebut pada kolom 2 (dua) dalam lampiran yang merupakan bagian tak terpisahkan dari surat perintah ini.</td>
    </tr>
    <tr>
    <td valign="top">Untuk</td>
        <td valign="top">:</td>
        <td align="justify">
            a. Menghadiri dan memfasilitasi kegiatan Sosialisasi dan Bimbingan Teknis Adminduk Dinas Kependudukan dan Pencatatan Sipil Kabupaten Boyolali yang akan dilaksanakan di Front One Budget Boyolali (Jl. Boulevard Soekarno, Wonosari, Kemiri, Mojosongo, Boyolali, Jawa Tengah 57482) pada hari Rabu tanggal 23 Oktober 2024.<br><br>
            b. Mengkoordinasikan tugas dan tanggung jawab dengan pihak terkait guna kelancaran dan kesuksesan pelaksanaan kegiatan.
        </td>
    </tr>
</table>

<br>
<br>

<table width="100%" cellspacing="0" cellpadding="5">
    <tr>
        <td width="60%"></td>
        <td align="center">
            Ditetapkan di Boyolali<br>
            pada tanggal 14 Oktober 2024<br>
            KEPALA DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL<br>
            Kabupaten Boyolali<br><br><br><br><br>
            <b>Drs. Susilo Hartono</b><br>
            Pembina Utama Muda<br>
            NIP. 19680429 198803 1 002
        </td>
    </tr>
</table>

<br>

<table width="100%" cellspacing="0" cellpadding="5">
    <tr>
        <td><b>Tembusan:</b></td>
    </tr>
    <tr>
    <td align="justify">1. Yang bersangkutan;</td>
    </tr>
    <tr>
    <td align="justify">2. <a href="#">Pertinggal</a></td>
    </tr>
</table>


<br><br>
<table width="100%" cellspacing="0" cellpadding="5">
    <tr>
        <td align="center"><b>SUSUNAN PANITIA SOSIALISASI DAN BIMTEK ADMINDUK</b></td>
    </tr>
    <tr>
        <td align="center"><b>DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL KABUPATEN BOYOLALI</b></td>
    </tr>
    <tr>
        <td align="center">RABU, 23 OKTOBER 2024</td>
    </tr>
</table>

<br>

<!-- Tabel Susunan Panitia -->
<table width="100%" border="1" cellspacing="0" cellpadding="5">
    <tr align="center">
        <th>No</th>
        <th>Nama</th>
        <th>Jabatan Dalam Kepanitiaan</th>
        <th>Tugas Dan Tanggung Jawab</th>
    </tr>
    <tr>
        <td align="center">1</td>
        <td>Drs. Susilo Hartono</td>
        <td>Penanggung Jawab</td>
        <td>Sambutan</td>
    </tr>
    <tr>
        <td align="center">2</td>
        <td>Purwanto, SE, MM</td>
        <td>Ketua</td>
        <td>Laporan Kegiatan</td>
    </tr>
    <tr>
        <td align="center">3</td>
        <td>Dwi Antoni Setya Budi, S.Kom</td>
        <td>Sekretaris</td>
        <td>Koordinator Administrasi</td>
    </tr>
    <tr>
        <td align="center">4</td>
        <td>Erna Setyowati, S.H</td>
        <td>Anggota</td>
        <td>Koordinator Konsumsi</td>
    </tr>
    <tr>
        <td align="center">5</td>
        <td>Benny Danang Kurniawan, S.Kom</td>
        <td>Anggota</td>
        <td>Operator</td>
    </tr>
    <tr>
        <td align="center">6</td>
        <td>Aris Nugroho, A.Md.Kom</td>
        <td>Anggota</td>
        <td>Operator</td>
    </tr>
    <tr>
        <td align="center">7</td>
        <td>Lifia Puspitasari, S.A.P</td>
        <td>Anggota</td>
        <td>Daftar Hadir</td>
    </tr>
    <tr>
        <td align="center">8</td>
        <td>Asri Krisnawati, S.Ak</td>
        <td>Anggota</td>
        <td>Dirijen dan Dokumentasi</td>
    </tr>
    <tr>
        <td align="center">9</td>
        <td>Sri Wahyuni, A.Md</td>
        <td>Anggota</td>
        <td>MC</td>
    </tr>
    <tr>
        <td align="center">10</td>
        <td>Danang Fitrianto Nugroho, A.Md</td>
        <td>Anggota</td>
        <td>Do'a</td>
    </tr>
</table>

<br><br>

<table width="100%">
    <tr>
        <td width="60%"></td>
        <td align="center">
            Boyolali, 14 Oktober 2024<br>
            Kepala Dinas Kependudukan<br>
            dan Pencatatan Sipil Kab. Boyolali<br><br><br><br><br>
            <b>Drs. Susilo Hartono</b><br>
            Pembina Utama Muda<br>
            NIP. 19680429 198803 1 002
        </td>
    </tr>
</table>


</body>
</html>
<script>
    window.print();  
</script>