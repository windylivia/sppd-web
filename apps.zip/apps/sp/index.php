<?php
include("../koneksi.php");

// Filter rentang tanggal
$filterQuery = "";
if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
    $start_date = $_GET['start_date'];
    $end_date = $_GET['end_date'];

    if (!empty($start_date) && !empty($end_date)) {
        $filterQuery = "WHERE surat_perintah.tgl_input BETWEEN '$start_date' AND '$end_date'";
    }
}

// Ambil data Surat Perintah dengan filter
$result = $conn->query("SELECT * FROM surat_perintah $filterQuery");
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title>Surat Perintah</title>
    </head>
    <body>
        <h1>Indeks Surat Perintah</h1>

        <!-- Form Filter Tanggal -->
        <form method="GET">
            <label for="start_date">Dari:</label>
            <input type="date" name="start_date" id="start_date" value="<?= isset($_GET['start_date']) ? $_GET['start_date'] : '' ?>">
            
            <label for="end_date">Sampai:</label>
            <input type="date" name="end_date" id="end_date" value="<?= isset($_GET['end_date']) ? $_GET['end_date'] : '' ?>">
            
            <button type="submit">Filter</button>
            <a href="index.php">Clear</a>
        </form>
        
        <!-- Tabel Surat Perintah -->
        <table border="1" cellpadding="5" cellspacing="0">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nomor Surat</th>
                    <th>Menimbang</th>
                    <th>Dasar</th>
                    <th>Kepada</th>
                    <th>Untuk</th>
                    <th>Tanggal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; while ($row = $result->fetch_assoc()) : ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $row['nomor_surat'] ?></td>
                    <td><?= $row['menimbang'] ?></td>
                    <td><?= $row['dasar'] ?></td>
                    <td><?= $row['kepada'] ?></td>
                    <td><?= $row['untuk'] ?></td>
                    <td><?= $row['tgl_input'] ?></td>
                    <td>
                        <a href="cetak.php?id=<?= $row['id_surat'] ?>">Cetak</a>
                        <a href="update.php?id=<?= $row['id_surat'] ?>">Edit</a>
                        <a href="delete.php?id=<?= $row['id_surat'] ?>" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </body>
</html>