<?php
session_start();
include("koneksi.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Ambil password lama dari database
    $query = "SELECT password FROM login WHERE id_user = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    // Cek apakah password lama cocok (tanpa hashing)
    if ($current_password === $user['password']) { 
        if ($new_password === $confirm_password) {
            // Update password baru (tanpa hashing)
            $update_query = "UPDATE login SET password = ? WHERE id_user = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param("si", $new_password, $user_id);

            if ($update_stmt->execute()) {
                $_SESSION['success'] = "Password berhasil diubah!";
                header("Location: ganti_password.php"); // Redirect ke halaman yang sama
                exit();
            } else {
                $error = "Gagal mengubah password!";
            }
        } else {
            $error = "Password baru dan konfirmasi tidak cocok!";
        }
    } else {
        $error = "Password lama salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Ganti Password - Sistem SPPD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        body {
            background-color: black;
        }
        .password-container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .card {
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            padding: 20px;
        }
        .card-header {
            background: url('gambar/dukcapil.jpg') no-repeat center;
            background-size: cover;
            color: white;
            text-align: center;
            font-size: 1.5rem;
            font-weight: bold;
            height: 150px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        .card-header::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
        }
        .card-header span {
            position: relative;
            z-index: 1;
        }
    </style>
</head>
<body>
    <div class="container password-container">
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header"><span>GANTI PASSWORD</span></div>
                <div class="card-body">
                    <?php if (!empty($_SESSION['success'])): ?>
                        <div class="alert alert-success" role="alert">
                            <?php 
                                echo $_SESSION['success']; 
                                unset($_SESSION['success']); // Hapus pesan setelah ditampilkan
                            ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo $error; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <div class="form-floating flex-grow-1">
                                <input class="form-control" id="current_password" type="password" name="current_password" placeholder="Password Lama" required />
                                <label for="current_password">Password Lama</label>
                            </div>
                        </div>

                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <div class="form-floating flex-grow-1">
                                <input class="form-control" id="new_password" type="password" name="new_password" placeholder="Password Baru" required />
                                <label for="new_password">Password Baru</label>
                            </div>
                        </div>

                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <div class="form-floating flex-grow-1">
                                <input class="form-control" id="confirm_password" type="password" name="confirm_password" placeholder="Konfirmasi Password" required />
                                <label for="confirm_password">Konfirmasi Password</label>
                            </div>
                        </div>

                        <div class="d-flex flex-column align-items-center mt-3">
                            <button type="submit" class="btn btn-warning w-100">
                                <i class="fa fa-key me-2"></i> Ganti Password
                            </button>
                        </div>

                        <div class="text-center mt-3">
                            <?php if ($_SESSION['role'] == 'admin') : ?>
                                <a href="dashboard/index.php" class="btn btn-secondary w-100">Kembali</a>
                            <?php else : ?>
                                <a href="dashboard2/index.php" class="btn btn-secondary w-100">Kembali</a>
                            <?php endif; ?>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>
