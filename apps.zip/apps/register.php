<!DOCTYPE html>
<?php
include("koneksi.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    $query = "INSERT INTO login (username, password, role) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sss", $username, $password, $role);

    if ($stmt->execute()) {
        header("Location: index.php?success=1");
        exit();
    } else {
        $error = "Pendaftaran gagal, silakan coba lagi.";
    }
}
?>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Pendaftaran - Sistem SPPD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        body {
            background-color: black;
        }
        .register-container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .card {
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            padding: 20px;
        }
        .card-header {
            background: url('gambar/dukcapil.jpg') no-repeat center;
            background-size: cover;
            color: white;
            text-align: center;
            font-size: 1.5rem;
            font-weight: bold;
            height: 150px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        .card-header::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
        }
        .card-header span {
            position: relative;
            z-index: 1;
        }
        .input-group select {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background-color: white;
            padding-right: 2rem;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container register-container">
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header"><span>DAFTAR - SISTEM SPPD</span></div>
                <div class="card-body">
                    <form method="POST" action="">
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo $error; ?>
                            </div>
                        <?php endif; ?>
                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <div class="form-floating flex-grow-1">
                                <input class="form-control" id="username" type="text" name="username" placeholder="Nama Pengguna" required />
                                <label for="username">Nama Pengguna</label>
                            </div>
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <div class="form-floating flex-grow-1">
                                <input class="form-control" id="password" type="password" name="password" placeholder="Kata Sandi" required />
                                <label for="password">Kata Sandi</label>
                            </div>
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fas fa-user-tag"></i></span>
                            <select class="form-select" id="role" name="role" required>
                                <option value="" disabled selected>Pilih Peran</option>
                                <option value="pegawai">Pegawai</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                        <div class="d-flex flex-column align-items-center mt-3">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fa fa-user-plus me-2"></i> Daftar
                            </button>
                        </div>
                        <div class="text-center mt-3">
                            <a href="index.php" class="btn btn-secondary w-100">Kembali</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>
