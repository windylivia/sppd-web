<?php
include("../koneksi.php");
$menu = $conn->query("SELECT * FROM menu");

// Ambil data perjalanan kota
$result = $conn->query("SELECT 
    perjalanan_kota.*, 
    perjalanan.perjalanan, 
    pegawai.nama AS nama_pegawai, 
    bbm.kecamatan 
FROM perjalanan_kota
LEFT JOIN perjalanan ON perjalanan_kota.id_perjalanan = perjalanan.id_perjalanan
LEFT JOIN pegawai ON perjalanan_kota.id_pegawai = pegawai.id_pegawai
LEFT JOIN bbm ON perjalanan_kota.id_bbm = bbm.id_bbm");

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Perjalanan Kota</title>
        <link href="../page/https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="../page/css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-5" href="../index.php">SISDUK</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#!">Settings</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="../index.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <br><br>
                            <a class="nav-link" href="../dashboard">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Master Surat
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="../sppd/index.php"> <i class="fa-regular fa-file-lines"></i> &nbsp;Data SPPD</a>
                                    <a class="nav-link" href="../sp/index.php"> <i class="fa-regular fa-file-lines"></i> &nbsp;Data SPT</a>
                                </nav>
                            </div>
                        
                            <!-- menu dinamis -->
                             <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#appx" aria-expanded="false" aria-controls="appx">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-bars"></i></div>Data Master
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="appx" aria-labelledby="headingAppx" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <?php if ($menu->num_rows > 0): ?>
                                        <?php while ($row = $menu->fetch_assoc()) : ?>
                                            <a class="nav-link" href="<?= $row['link_menu'] ?>">
                                                <i class="sb-nav-link-icon <?= $row['icon_menu'] ?>"></i>
                                                <span class="ms-2"><?= $row['nama_menu'] ?></span>
                                            </a>
                                            <?php endwhile; ?>
                                            <?php else: ?>
                                                <a class="nav-link" href="#">
                                                    <i class="sb-nav-link-icon fa fa-exclamation-triangle"></i>
                                                    <span class="ms-2">No Data Master Available</span>
                                                </a>
                                                <?php endif; ?>
                                            </nav>
                                        </div>

                            <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                     </nav>
                                    </div>
                                </div>
                            </div>
                        </nav>
                    </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Perjalanan Kota</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="../dashboard">Dashboard</a></li>
                            <li class="breadcrumb-item active">Perjalanan Kota</li>
                        </ol>

                        <!-- table -->
                         <div class="card mb-4">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span>
                                    <i class="fas fa-table me-1"></i>
                                    Data Perjalanan Kota
                                </span>
                                <!-- Tombol Add -->
                                 <a href="add.php" class="btn btn-primary btn-sm">
                                    <i class="fas fa-plus me-1"></i> Tambah Data
                                </a>
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple" class="custom-table">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Pegawai</th>
                                            <th>perjalanan</th>
                                            <th>BBM (Kecamatan)</th>
                                            <th>> 8 Jam < 5 KM</th>
                                            <th>> 8 Jam > 5 KM</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 1; while ($row = $result->fetch_assoc()) : ?>
                                        <tr>
                                            <td><?= $no++; ?></td>
                                            <td><?= $row['nama_pegawai']; ?></td>
                                            <td><?= $row['perjalanan']; ?></td>
                                            <td><?= $row['kecamatan']; ?></td>
                                            <td><?= $row['kurang_8_jam_lebih_5_km']; ?></td>
                                            <td><?= $row['kurang_8_jam_kurang_5_km']; ?></td>
                                            <td>
                                                <div class="action-buttons">
                                                    <a href="update.php?id=<?= $row['id_perjalanan_kota'] ?>" class="btn btn-warning btn-sm me-2"><i class="fa-solid fa-pen-to-square"></i>
                                                    Edit</a>
                                                    <a href="delete.php?id=<?= $row['id_perjalanan_kota'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data ini?')"><i class="fa-solid fa-trash"></i>
                                                    Hapus</a>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- end tabel-->
                        </main>
                        </div>
                    </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../page/js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="../page/assets/demo/chart-area-demo.js"></script>
        <script src="../page/assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="../page/js/datatables-simple-demo.js"></script>
    </body>
</html>
