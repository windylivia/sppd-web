<?php
include("../Koneksi.php");

$id_perjalanan_kota = $_GET['id'];

$query = "DELETE FROM perjalanan_kota WHERE id_perjalanan_kota = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_perjalanan_kota);
$stmt->execute();

header("Location: index.php");
?>